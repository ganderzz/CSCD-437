Ruby required to run
	- Can be installed from: https://www.ruby-lang.org/en/

How to Use:
	From the terminal, use the command 
		$ ruby main.rb

	Redirection of an input file also possible
		$ ruby main.rb < test.txt


This program will output a text file (output.txt) with all the commands, the input entered, and if the input passed or failed the regexp test.



No short commings in this assignment